# AGENTS.md

Behavioral guidelines to reduce common LLM coding mistakes. Merge with project-specific instructions as needed.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment.

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them - don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it - don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: Every changed line should trace directly to the user's request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

---

**These guidelines are working if:** fewer unnecessary changes in diffs, fewer rewrites due to overcomplication, and clarifying questions come before implementation rather than after mistakes.

---

## 项目特定约定（github-skills）

- 只用 Python 标准库；不引第三方依赖。
- **账号 = `.tokens` 的一行**，不固定任何账号；用 `--as` / `as` 前缀 / `.active` 切换。
- 写操作前 `resolve()` 解析身份 + `precheck_push()` 查权限；**指定账号不匹配就拒绝，不降级**。
- 分支合并只做 `force=false` 纯快进；`ahead!=1 or behind!=0` 直接拒绝。
- **v1.3.0**：`sync` 默认合并（带 `base_tree`），删除线上文件必须显式 `--mirror`；不默认删他人文件。
- **v1.3.0**：大仓用 `pull --zip`（一次 zipball + 一次 tree），别逐文件 GET /contents；tree 截断时明确标 `unverified`，不给假绿灯。
- **v1.3.0**：无 `.tokens` 时只读命令走匿名身份，写命令由 `guard()` 拒绝；`doctor` 打印 `/rate_limit` 额度。
- **v1.3.0**：`.ghproj` 存一行 JSON（`repo` / `branch` / `commit`），兼容旧纯文本；分支优先读它。
- **v1.3.0**：新增 `pages` 命令与 `new --pages`，补齐「建仓 → 写 → 推 → 校验 → 开 Pages」的最后一环。
- 校验一致性一律用 git blob sha，不用「文件大小差不多」。
- token 值不进日志、不进交付包、不进 commit；`.active` 只存 login / 行号。
- 验证阶段用 `--dry-run`，不制造真实写入。
- 中文输出，命令名保持英文；不追加未要求的配置项。

来源：`forrestchang/andrej-karpathy-skills` @ `2c60614`（原文镜像在 `guides/karpathy/`）。
