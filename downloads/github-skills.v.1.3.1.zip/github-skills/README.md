# github-skills v1.3.1

> **v1.3.1**：修掉 `pull` / `spm install --file` 把 >1 MB 文件静默写空包的 bug，
> 新增 `github pr <repo> --merge N`。61 项离线回归全绿。详见 `CHANGES-v1.3.1.md`。

---

# v1.3.0 原始说明

自包含的**多账号** GitHub 操作 skill 包：一个 CLI、一层薄 API 封装、几个能单独拷走用的脚本、离线回归测试，外加 Karpathy 四条行事准则原文。

> **v1.3.0 变化**：补齐开 Pages、大仓 zip 拉取、匿名只读、`--owner`；最重要的是 **`sync` 从默认「镜像（会删线上文件）」改成默认「合并」**，删除必须显式 `--mirror`。

**零第三方依赖**，Python 3.8+ 即可跑。

## 为什么不是「固定某账号」

账号就是 `.tokens` 的一行。固定某账号写进代码，遇到协作者仓库、只读账号、临时换身份就得多改一处脚本。这里改成：

```
默认账号   .active（github use 设定，只存 login）→ 没设就第 1 行
单次覆盖   --as <login|行号>  /  github as <账号> <命令>  /  github <账号> <命令>
```

分工照旧能保留（比如把默认设成 Cool-zimo），但**随时能切**，不用改代码。

## 30 秒开始

```bash
unzip github-skills.v.1.2.0.zip
cd github-skills
cp .tokens.example .tokens      # 每行填一个自己的 PAT，别提交

python3 github doctor
python3 github users            # 看每个账号是谁、有没有失效
python3 github use Cool-zimo    # 设默认（可不设，默认第 1 行）
python3 github whoami
python3 github doctor                 # 顺带打印 API 剩余配额
```

`.tokens` 放在包根或**向上 4 层内任意一级**都行（本机是 `/data/workspace/.tokens`，包在 `/data/workspace/github-skills/`，自动向上找）；放得更远就 `export GH_TOKENS_FILE=/path/to/.tokens`。

建议加个别名：

```bash
alias github='python3 /data/workspace/github-skills/github'
```

## 账号管理

```bash
github users                                    # 列账号 / id / scope / 失效状态
github users --repo Cool-zimo/github_drive      # 附带每个账号对该仓库的 push/admin
github use causepotato                          # 设默认
github use --clear                              # 清除默认，回第 1 行
github whoami                                   # 当前生效的是谁、第几行
```

输出**从不显示 token 值**。`.active` 是运行时文件，不进交付包（见 `.gitignore`）。

四种单次切账号写法等价：

```bash
github as causepotato status Cool-zimo/github_drive
github causepotato status Cool-zimo/github_drive
github status Cool-zimo/github_drive --as causepotato
github status Cool-zimo/github_drive --as 3        # 行号也行
```

写操作前会自动：解析身份 → 校验精确匹配（不降级）→ 查目标仓库 `permissions.push`。**没 push 权限直接拒绝并提示换账号**，不会等到 403 才发现。

可选：`export GH_EXPECT_LOGIN=Cool-zimo` 做全局强校验，不符拒绝。默认不设。

## 命令速查

```bash
# 读
github tree Cool-zimo/github_drive --limit 20
github status Cool-zimo/github_drive     # 仓库 + 我的权限 + Pages + 最新构建
github pr free-domains/is-a.bot --state all
github collab Cool-zimo/github_drive

# 拉 / 校验
github new repo my-demo --dry-run        # 建仓并拉到 projects/
github clone Cool-zimo/github_drive      # git clone，403 自动回退 API
github pull forrestchang/andrej-karpathy-skills ./out
github verify ./out --repo forrestchang/andrej-karpathy-skills

# 一条龙：建仓 → 写代码 → 整目录一次推 → 自动校验
github new repo my-demo
cd projects/my-demo
# ...写测试 → 复现失败 → 写实现 → 跑通...
github sync . -m "feat: xxx" --dry-run
github sync . -m "feat: xxx"        # 3 文件只需一条命令，末尾自动逐字节校验
github verify .                      # 仓库名不用再写，读 .ghproj

# 写（都支持 --dry-run）
github push a.txt --repo Cool-zimo/github_drive --path a.txt -m "update a"
github as causepotato push a.txt --repo causepotato/github_drive --path a.txt -m "from collab"
github ff Cool-zimo/github_drive fix/code-review --sha 3bb5ad2 --base 19b57bf

# 读准则
github guide                             # 使用指南
github guide 踩坑记录.md
github guide karpathy/CLAUDE.md
```

`github new <名>` 与 `github new repo <名>` 等价。

## 目录

```
github-skills/
├── SKILL.md              ← Agent 加载入口（frontmatter + 命令表 + 工作流）
├── AGENTS.md             ← Karpathy 四条 + 本项目约定
├── README.md
├── .tokens.example  .gitignore
├── github                ← CLI 唯一入口
├── ghlib.py              ← 薄 REST 封装（唯一 API 实现源）
├── .active               ← 运行时生成，不进交付包
├── projects/             ← clone / new 的默认落地点
├── scripts/              ← 可单独拷走的现成脚本，都支持 --as
│   ├── push.py           推单文件（--check 零写入、--dry-run）
│   ├── clone_via_api.py  tree+contents 镜像 + 逐字节校验
│   ├── verify_mirror.py  本地 vs 线上一致性
│   └── pages_status.py   Pages 状态 / --wait 轮询
└── guides/
    ├── 使用指南.md       命令详解 + 典型工作流
    ├── 踩坑记录.md       本机真实踩过的坑（很有用）
    └── karpathy/         forrestchang/andrej-karpathy-skills 原文 9 文件镜像
```

`projects/` 只放 `.gitkeep`，不预置仓库内容 —— 用 `github clone` 自己拉，包才不会塞进几百个站点文件。

没找到 `.tokens` 也能跑只读命令（`tree` / `status` / `verify` / `pr` / `collab` / `pages`），工具自动用匿名身份查公开仓；写命令会明确要求 `.tokens`。

## 设计取舍

- **一个 CLI + 一层库**：命令多但实现只有一份，改 API 行为只动 `ghlib.py`。
- **`.ghproj` 项目标记**：`clone` / `pull` / 显式 `--repo` 的 `sync` 会在工作目录写一行仓库全名，之后 `sync` / `verify` / `push` / `status` / `tree` 都不用再敲仓库名；短名自动按当前账号补全。
- **`sync` 是整目录镜像**：一次 commit，未变文件复用线上 blob sha，只对改动文件 POST；`__pycache__` / `.pyc` 等缓存统一排除，`sync` 与 `verify` 共用同一套规则，不会假红；无变化时不产生空提交。
- **账号动态探测**：`users` / `--as <login>` 直接调 `/user` 认账号，不维护手写映射表，加一行 token 就多一个账号。
- **clone 403 自动回退**：本机 `git clone` 恒 403，靠 tree + contents 落盘，并用 git blob sha 逐字节校验。
- **写操作前置校验**：身份、权限、基线、ahead/behind、`--dry-run`，都是前几轮真踩过坑之后加的。
- **准则与工具同包**：`SKILL.md` 直接引用 `AGENTS.md`，Agent 一加载就同时拿到工具和行事风格。

## v1.3.0 改了什么（对应实测的 6 条意见）

| # | 问题 | 现在 |
|---|---|---|
| 1 | 一条龙断在最后一步，开 Pages 要手写 `G.req("POST", ...)` | `github pages [o/r] --enable --wait`；或 `new repo <名> --pages` 一步到位 |
| 2 | `sync` 默认镜像，加个文件会把线上 README 删掉 | 默认合并（带 `base_tree`），删除必须 `--mirror`，dry-run 用 `⚠️` 列删除清单 |
| 3 | `pull` 逐文件 GET /contents，50 篇 md 连续 502 | `pull --zip` / `clone --zip`：zipball 一次下载 + 一次 tree，仍逐字节校验；tree 截断明确报 `unverified` |
| 4 | 只读公开仓也强制要 token；撞限流时 doctor 看不出来 | 匿名只读模式；`doctor` 打印 `/rate_limit` 剩余额度 |
| 5 | `new` 只能建在当前账号名下 | `--owner <org>` 走 `/orgs/{org}/repos`；别的普通用户名明确报错并提示 `--as`；目标用 `★` 标出 |
| 6 | guide 写死 4 个文件 / status 在包根报错 / 默认分支写死 main | `guide --list` + 任意 guides/ 路径（带越界防护）；包根自动选中唯一 project；`.ghproj` 存 JSON 含 `branch` / `commit` |

## 内置包管理器 spm

`spm` 随本包一起分发，**默认把版本装到 skill 包的 `skills/` 目录**（`SPM_HOME` 可改）。
开箱即可同时装 1.2.0 / 1.3.0 两个版本：

```bash
python3 spm install github-skills@1.2.0 --trust --allow python3 --script "check=python3 github --help"
python3 spm install github-skills@1.3.0 --from pr:Cool-zimo/github-skills-lab#1:downloads
python3 spm list
python3 spm v12          # 别名 → run github-skills@1.2.0 check
```

覆盖：自定义下载源（github / url / path / **pr**）、多版本并存与 `use`、安全模式与版本目录限制、
`trust` 信任、`allow` 命令白名单、独立版本根与 env、**VFS 虚拟文件系统**（写只落 sandbox，不污染版本根）、
自定义脚本 `run` / `exec`、命令别名管理、token 文件同步（值不回显）。

完整说明：[SPM.md](SPM.md) · [guides/使用spm.md](guides/使用spm.md) · 25 项离线回归 `tests/test_spm.py`。

**没动**：`--dry-run` 的 `~/-/复用` 清单、git blob sha 逐字节校验、未变文件复用线上 sha、noop 不刷空提交、`force:false` 纯快进。

回归测试：`python3 -m unittest discover -s tests -v` → **49 项全绿**（24 项 v1.3.0 + 25 项 spm），全部离线、不需要 token。

## 许可

MIT（karpathy 镜像沿用上游 MIT）。
