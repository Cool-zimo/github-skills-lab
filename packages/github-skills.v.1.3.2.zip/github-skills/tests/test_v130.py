#!/usr/bin/env python3
"""github-skills v1.3.0 离线回归测试。零第三方依赖，不碰网络、不需要 token。

按 Karpathy 第四条：每条优化先写一个能复现 v1.2.0 问题的测试，再验 v1.3.0 修好了。

    python3 -m unittest discover -s tests -v
"""
import argparse
import base64
import contextlib
import hashlib
import importlib.machinery
import importlib.util
import io
import json
import os
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import ghlib as G  # noqa: E402

CLI_PATH = os.path.join(ROOT, "github")
_loader = importlib.machinery.SourceFileLoader("ghcli", CLI_PATH)
_spec = importlib.util.spec_from_loader("ghcli", _loader)
CLI = importlib.util.module_from_spec(_spec)
_loader.exec_module(CLI)


def make_tree_zip(files):
    """构造一个仿 GitHub zipball：顶层目录 owner-repo-sha/。"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for rel, data in files.items():
            z.writestr("owner-repo-abc123/" + rel, data)
    return buf.getvalue()


class FakeAPI(object):
    """替换 G.req：按 path 分发，记录每次调用。"""

    def __init__(self, online=None, tree_sha="TREE_OLD"):
        self.calls = []
        self.online = online or {}
        self.tree_sha = tree_sha

    def __call__(self, method, path, token, body=None, params=None):
        self.calls.append((method, path, body, params))
        if method == "GET" and "/git/trees/" in path:
            return 200, {"sha": self.tree_sha, "truncated": False,
                         "tree": [{"path": p, "type": "blob", "sha": s}
                                  for p, s in sorted(self.online.items())]}
        if method == "GET" and "/git/ref/heads/" in path:
            return 200, {"object": {"sha": "COMMIT_OLD"}}
        if method == "POST" and path.endswith("/git/blobs"):
            return 201, {"sha": "BLOB_NEW"}
        if method == "POST" and path.endswith("/git/trees"):
            return 201, {"sha": "TREE_NEW"}
        if method == "POST" and path.endswith("/git/commits"):
            return 201, {"sha": "COMMIT_NEW"}
        if method == "PATCH" and "/git/refs/" in path:
            return 200, {"object": {"sha": "COMMIT_NEW"}}
        if method == "POST" and path.endswith("/pages"):
            return 201, {"html_url": "https://x.github.io/y/", "status": None}
        if method == "GET" and path == "/rate_limit":
            return 200, {"resources": {"core": {"remaining": 4999, "limit": 5000, "reset": 0}}}
        if method == "GET" and path.startswith("/orgs/"):
            return 200, {"login": path.split("/")[-1]}
        return 200, {}


class TestVersionAndBasics(unittest.TestCase):

    def test_01_version(self):
        self.assertEqual(G.VERSION, "1.3.2")

    def test_02_blob_sha_unchanged(self):
        """逐字节校验这块没动：仍等于 git blob sha。"""
        for data in (b"hello\n", b"# hi\n", b"\xe4\xb8\xad\xe6\x96\x87\n", b""):
            expected = hashlib.sha1(
                b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()
            self.assertEqual(G.blob_sha(data), expected)

    def test_03_is_sync_path_rules_unchanged(self):
        self.assertFalse(G.is_sync_path("__pycache__/x.pyc"))
        self.assertFalse(G.is_sync_path(".ghproj"))
        self.assertTrue(G.is_sync_path("index.html"))


class TestProblem2_SyncMergeDefault(unittest.TestCase):
    """v1.2.0：本地只放 index.html，sync 默认就把线上 README 删了。"""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        with open(os.path.join(self.tmp, "index.html"), "wb") as f:
            f.write(b"<h1>hi</h1>\n")
        self.orig_req = G.req
        # 线上有 README.md，本地没有
        self.fake = FakeAPI(online={"README.md": "SHA_README"})
        G.req = self.fake

    def tearDown(self):
        G.req = self.orig_req

    def _trees_posts(self):
        return [c for c in self.fake.calls if c[0] == "POST" and c[1].endswith("/git/trees")]

    def test_04_default_dry_run_does_not_delete(self):
        r = G.sync_tree("tok", "o/r", self.tmp, "msg", dry_run=True)
        self.assertEqual(r["removed"], [])
        self.assertEqual(r["kept"], ["README.md"])
        self.assertFalse(r["mirror"])
        self.assertEqual(self._trees_posts(), [])  # dry-run 零写入

    def test_05_default_real_run_uses_base_tree(self):
        r = G.sync_tree("tok", "o/r", self.tmp, "msg")
        self.assertEqual(r["removed"], [])
        posts = self._trees_posts()
        self.assertEqual(len(posts), 1)
        self.assertIn("base_tree", posts[0][2])
        self.assertEqual(posts[0][2]["base_tree"], "TREE_OLD")
        self.assertIsNotNone(r["commit"])

    def test_06_mirror_still_deletes_but_is_explicit(self):
        r = G.sync_tree("tok", "o/r", self.tmp, "msg", dry_run=True, mirror=True)
        self.assertEqual(r["removed"], ["README.md"])
        self.assertEqual(r["kept"], [])
        self.assertTrue(r["mirror"])
        r2 = G.sync_tree("tok", "o/r", self.tmp, "msg", mirror=True)
        posts = self._trees_posts()
        self.assertEqual(len(posts), 1)
        self.assertNotIn("base_tree", posts[0][2])
        self.assertIsNotNone(r2["commit"])

    def test_07_noop_unchanged(self):
        """无改动时不产生空提交 —— 别改的部分。"""
        # 让本地文件的 blob sha 与线上一致
        with open(os.path.join(self.tmp, "index.html"), "rb") as f:
            data = f.read()
        self.fake.online = {"index.html": G.blob_sha(data)}
        r = G.sync_tree("tok", "o/r", self.tmp, "msg")
        self.assertTrue(r["noop"])
        self.assertIsNone(r["commit"])


class TestProblem2b_VerifyIgnoreExtra(unittest.TestCase):
    """合并语义下线上保留的文件不能让逐字节校验假红。"""

    def test_08_default_still_strict(self):
        tmp = tempfile.mkdtemp()
        with open(os.path.join(tmp, "index.html"), "wb") as f:
            f.write(b"abc")
        shas = {"index.html": G.blob_sha(b"abc"), "README.md": "SHA_README"}
        ok, total, bad = G.verify_mirror(tmp, shas)
        self.assertEqual(total, 2)
        self.assertTrue(any("README.md" in x for x in bad))

    def test_09_ignore_extra_only_skips_listed(self):
        tmp = tempfile.mkdtemp()
        with open(os.path.join(tmp, "index.html"), "wb") as f:
            f.write(b"abc")
        shas = {"index.html": G.blob_sha(b"abc"), "README.md": "SHA_README"}
        ok, total, bad = G.verify_mirror(tmp, shas, ignore_extra={"README.md"})
        self.assertEqual((ok, total, bad), (1, 1, []))

    def test_10_ignore_extra_does_not_hide_real_mismatch(self):
        tmp = tempfile.mkdtemp()
        with open(os.path.join(tmp, "index.html"), "wb") as f:
            f.write(b"WRONG")
        shas = {"index.html": G.blob_sha(b"abc"), "README.md": "SHA_README"}
        ok, total, bad = G.verify_mirror(tmp, shas, ignore_extra={"README.md"})
        self.assertEqual(ok, 0)
        self.assertIn("index.html", bad)


class TestProblem3_ZipPull(unittest.TestCase):
    """v1.2.0：50 篇 md 要 50 次 /contents，连续 502。"""

    def test_11_zip_pull_one_download_plus_one_tree(self):
        orig_zip, orig_req = G.zipball, G.req
        files = {"README.md": b"# readme\n", "docs/a.md": b"aaa\n", "docs/b.md": b"bbb\n"}
        G.zipball = lambda *a, **kw: make_tree_zip(files)
        fake = FakeAPI(online={p: G.blob_sha(d) for p, d in files.items()})
        G.req = fake
        try:
            dest = tempfile.mkdtemp()
            n, size, shas, status = G.pull_repo_zip("tok", "o/r", dest, "main")
            self.assertEqual(n, 3)
            self.assertEqual(status, "verified")
            ok, total, bad = G.verify_mirror(dest, shas)
            self.assertEqual((ok, total, bad), (3, 3, []))
            self.assertEqual(len(fake.calls), 1, "除 zipball 外只应调 1 次 tree")
            self.assertNotIn("/contents/", fake.calls[0][1])
        finally:
            G.zipball, G.req = orig_zip, orig_req

    def test_12_truncated_tree_is_unverified_not_fake_green(self):
        orig_zip, orig_req = G.zipball, G.req
        G.zipball = lambda *a, **kw: make_tree_zip({"a.md": b"a"})
        G.req = lambda *a, **kw: (200, {"truncated": True, "tree": []})
        try:
            dest = tempfile.mkdtemp()
            n, size, shas, status = G.pull_repo_zip("tok", "o/r", dest, "main")
            self.assertEqual(n, 1)
            self.assertEqual(status, "unverified")
            self.assertEqual(shas, {})
        finally:
            G.zipball, G.req = orig_zip, orig_req


class TestProblem4_AnonymousRead(unittest.TestCase):
    """v1.2.0：没 .tokens 连公开仓 tree 都看不了；doctor 看不出限流。"""

    def test_13_resolve_anonymous(self):
        tmp = tempfile.mkdtemp()
        i = G.resolve(tmp, allow_anonymous=True)
        self.assertIsNone(i["token"])
        self.assertEqual(i["login"], "(anonymous)")
        self.assertEqual(i["line"], 0)

    def test_14_req_omits_authorization_for_anonymous(self):
        captured = {}

        class FakeResp:
            status = 200

            def read(self):
                return b"{}"

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

        orig = G.urllib.request.urlopen
        def fake_open(req, timeout=None):
            captured["headers"] = dict(req.header_items())
            captured["method"] = req.get_method()
            return FakeResp()
        G.urllib.request.urlopen = fake_open
        try:
            st, d = G.req("GET", "/repos/o/r", None)
            self.assertEqual(st, 200)
            self.assertNotIn("Authorization", captured["headers"])
            self.assertIn("X-github-api-version", captured["headers"] or {})
        finally:
            G.urllib.request.urlopen = orig

    def test_15_rate_limit_readable_anonymously(self):
        orig = G.req
        G.req = FakeAPI()
        try:
            core = G.rate_limit(None)
            self.assertEqual(core["remaining"], 4999)
        finally:
            G.req = orig

    def test_16_guard_rejects_anonymous_write(self):
        i = {"token": None, "login": "(anonymous)", "line": 0, "source": "(no .tokens)"}
        with contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(G.GhError) as cm:
                CLI.guard(i, "o/r")
        self.assertIn("写操作需要", str(cm.exception))


    def test_24_write_commands_report_anonymous_clearly(self):
        """实测：初版匿名 sync 抛底层「找不到 .tokens」，提示不一致；应统一由 guard 拒绝。"""
        a = argparse.Namespace(dir=tempfile.mkdtemp(), repo="o/r", message="m",
                               mirror=False, dry_run=True, branch=None,
                               as_spec=None, line=1, strict=False)
        anon = {"token": None, "login": "(anonymous)", "line": 0,
                "source": "(no .tokens)", "id": None, "scopes": [], "spec": "anonymous"}
        orig = CLI.ident
        CLI.ident = lambda args, allow_anon=False: anon
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(G.GhError) as cm:
                    CLI.cmd_sync(a)
            self.assertIn("写操作需要", str(cm.exception))
        finally:
            CLI.ident = orig


class TestProblem5_PagesAndOwner(unittest.TestCase):
    """v1.2.0：开 Pages 要手写 G.req('POST', ...)；new 无法指定组织。"""

    def test_17_pages_enable_dry_run_no_write(self):
        orig = G.req
        fake = FakeAPI()
        G.req = fake
        try:
            d = G.pages_enable("tok", "o/r", "main", "/", dry_run=True)
            self.assertTrue(d["dry_run"])
            self.assertEqual(fake.calls, [])
            d2 = G.pages_enable("tok", "o/r")
            self.assertEqual(d2.get("html_url"), "https://x.github.io/y/")
            self.assertTrue(any(c[1].endswith("/pages") for c in fake.calls))
        finally:
            G.req = orig

    def test_18_create_repo_owner_uses_org_endpoint(self):
        orig = G.req
        fake = FakeAPI()
        G.req = fake
        try:
            G.create_repo("tok", "demo", owner="my-org", login="Feng-zimo")
            posts = [c for c in fake.calls if c[0] == "POST"]
            self.assertEqual(posts[-1][1], "/orgs/my-org/repos")
            fake.calls[:] = []
            G.create_repo("tok", "demo", owner="Feng-zimo", login="Feng-zimo")
            self.assertEqual([c for c in fake.calls if c[0] == "POST"][-1][1], "/user/repos")
        finally:
            G.req = orig

    def test_19_create_repo_rejects_foreign_user(self):
        orig = G.req
        G.req = lambda *a, **kw: (404, {"message": "Not Found"})
        try:
            with self.assertRaises(G.GhError) as cm:
                G.create_repo("tok", "demo", owner="SomeOtherUser", login="Feng-zimo")
            self.assertIn("--as", str(cm.exception))
        finally:
            G.req = orig


class TestProblem6_EverydayFriction(unittest.TestCase):
    """guide 写死 4 个文件 / status 包根报错 / .ghproj 只存仓库名。"""

    def test_20_guide_list_and_arbitrary_path(self):
        a = argparse.Namespace(list=True, which=None)
        a2 = argparse.Namespace(list=False, which="karpathy/EXAMPLES.md")
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(CLI.cmd_guide(a), 0)
            self.assertEqual(CLI.cmd_guide(a2), 0)

    def test_21_guide_blocks_path_traversal(self):
        a = argparse.Namespace(list=False, which="../../etc/passwd")
        with self.assertRaises(G.GhError) as cm:
            CLI.cmd_guide(a)
        self.assertIn("路径越界", str(cm.exception))

    def test_22_ghproj_json_and_legacy_compat(self):
        tmp = tempfile.mkdtemp()
        CLI.ghproj_write(tmp, "Feng-zimo/kousuan", "main", "abc1234")
        meta, path = CLI.ghproj_find(tmp)
        self.assertEqual(meta["repo"], "Feng-zimo/kousuan")
        self.assertEqual(meta["branch"], "main")
        self.assertEqual(meta["commit"], "abc1234")
        self.assertEqual(CLI.ref_of(argparse.Namespace(), fallback="main"), "main")
        # v1.2.0 的纯文本仍能读
        with open(os.path.join(tmp, ".ghproj"), "w", encoding="utf-8") as f:
            f.write("Cool-zimo/github_drive\n")
        meta2, _ = CLI.ghproj_find(tmp)
        self.assertEqual(meta2["repo"], "Cool-zimo/github_drive")
        self.assertNotIn("branch", meta2)

    def test_23_ref_of_reads_ghproj_branch(self):
        tmp = tempfile.mkdtemp()
        CLI.ghproj_write(tmp, "o/r", "develop")
        a = argparse.Namespace(ref=None, branch=None, dir=tmp)
        self.assertEqual(CLI.ref_of(a), "develop")
        self.assertEqual(CLI.ref_of(a, "branch"), "develop")
        self.assertEqual(CLI.ref_of(argparse.Namespace(ref="hotfix", dir=tmp)), "hotfix")


if __name__ == "__main__":
    unittest.main(verbosity=2)
