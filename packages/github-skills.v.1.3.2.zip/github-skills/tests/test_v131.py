#!/usr/bin/env python3
"""github-skills v1.3.1 离线回归。零第三方依赖、不联网、不碰真实 token。

复现的两个真 bug：
  1. /contents 对 >1MB 文件返回 encoding:none + content:"" → 旧代码静默写 0 字节
  2. spm install --file 同一条路径 → 静默装一个空包
外加：0 字节空文件不能被误判成大文件；pr --merge 的 dry-run 不写远端。

    python3 -m unittest discover -s tests -v
"""
import base64
import importlib.machinery
import importlib.util
import io
import os
import sys
import tempfile
import unittest
from unittest import mock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import ghlib as G  # noqa: E402

CLI_PATH = os.path.join(ROOT, "github")
_loader = importlib.machinery.SourceFileLoader("ghcli_v131", CLI_PATH)
_spec = importlib.util.spec_from_loader("ghcli_v131", _loader)
CLI = importlib.util.module_from_spec(_spec)
_loader.exec_module(CLI)


def _tree_item(path, data, mode="100644"):
    return {"path": path, "mode": mode, "type": "blob",
            "sha": G.blob_sha(data), "size": len(data), "url": "fake"}


class TestPullRepoBigFile(unittest.TestCase):
    """pull_repo 逐文件路径的大文件 / 空文件 / sha 不符。"""

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="gh131-")
        self.big = b"PK\x03\x04" + bytes(range(256)) * 40   # 10244 B 的假 zip
        self.item = _tree_item("downloads/tool.zip", self.big)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _call(self, contents_resp, blob_resp=(200, {})):
        def fake_contents(token, full, path, ref):
            return contents_resp

        def fake_req(method, path, token, body=None, params=None):
            if method == "GET" and "/git/blobs/" in path:
                return blob_resp
            if method == "GET" and "/git/trees/" in path:
                return 200, {"tree": [self.item], "truncated": False}
            return 200, {}

        with mock.patch.object(G, "tree", return_value=[self.item]), \
             mock.patch.object(G, "contents", side_effect=fake_contents), \
             mock.patch.object(G, "req", side_effect=fake_req):
            return G.pull_repo("fake", "o/r", self.tmp, "main")

    def test_01_contents_none_falls_back_to_blob_api(self):
        """>1MB 风格响应（encoding:none）必须走 blob API，落盘字节完整。"""
        resp = {"encoding": "none", "content": "", "size": len(self.big),
                "sha": self.item["sha"]}
        blob = (200, {"content": base64.b64encode(self.big).decode(),
                      "encoding": "base64", "size": len(self.big)})
        n, total, shas = self._call(resp, blob)
        with open(os.path.join(self.tmp, "downloads/tool.zip"), "rb") as f:
            got = f.read()
        self.assertEqual(got, self.big)          # 旧代码这里是 b""
        self.assertEqual((n, total), (1, len(self.big)))

    def test_02_zero_byte_file_does_not_call_blob_api(self):
        """0 字节 .gitkeep 不该被当成大文件（修 v1.3.1 自身引入的回归）。"""
        empty = b""
        item = _tree_item("skills/.gitkeep", empty)
        self.item = item
        with mock.patch.object(G, "tree", return_value=[item]), \
             mock.patch.object(G, "contents",
                               return_value={"encoding": "base64", "content": "", "size": 0,
                                             "sha": item["sha"]}), \
             mock.patch.object(G, "req", side_effect=AssertionError("不该调 blob API")):
            n, total, _ = G.pull_repo("fake", "o/r", self.tmp, "main")
        self.assertEqual((n, total), (1, 0))
        with open(os.path.join(self.tmp, "skills/.gitkeep"), "rb") as f:
            self.assertEqual(f.read(), b"")

    def test_03_wrong_blob_sha_is_rejected(self):
        """取回内容与 tree sha 不符必须报错，不给假绿灯。"""
        resp = {"encoding": "none", "content": "", "size": len(self.big),
                "sha": self.item["sha"]}
        blob = (200, {"content": base64.b64encode(b"corrupted").decode(),
                      "encoding": "base64"})
        with self.assertRaises(G.GhError) as cm:
            self._call(resp, blob)
        self.assertIn("不符", str(cm.exception))

    def test_04_blob_api_failure_is_not_silent(self):
        resp = {"encoding": "none", "content": "", "size": len(self.big),
                "sha": self.item["sha"]}
        with self.assertRaises(G.GhError) as cm:
            self._call(resp, (404, {"message": "Not Found"}))
        self.assertIn("大文件取回失败", str(cm.exception))


class TestPrMerge(unittest.TestCase):
    def test_09_dry_run_never_writes(self):
        """--dry-run 只读 PR，绝不 PUT /merge。"""
        pr = {"title": "demo", "state": "open", "mergeable": True,
              "mergeable_state": "clean", "head": {"sha": "a" * 40},
              "base": {"sha": "b" * 40}}
        calls = []

        def fake_req(method, path, token, body=None, params=None):
            calls.append((method, path))
            return (200, pr) if method == "GET" else (200, {"merged": True})

        args = type("A", (), dict(repo="o/r", merge=2, method="merge", message="",
                                  dry_run=True, as_spec=None, line=1))()
        with mock.patch.object(CLI, "ident", return_value={"login": "tester", "line": 1,
                                                          "token": "fake"}), \
             mock.patch.object(CLI, "guard", return_value={"push": True, "admin": True}), \
             mock.patch.object(G, "req", side_effect=fake_req), \
             mock.patch("sys.stdout", new_callable=io.StringIO) as out:
            self.assertEqual(CLI.cmd_pr_merge(args), 0)
        self.assertIn("dry-run", out.getvalue())
        self.assertEqual([m for m, _ in calls], ["GET"])   # 没有 PUT

    def test_10_closed_or_conflicted_pr_is_stopped(self):
        pr = {"title": "demo", "state": "closed", "mergeable": True,
              "head": {"sha": "a" * 40}, "base": {"sha": "b" * 40}}
        args = type("A", (), dict(repo="o/r", merge=2, method="merge", message="",
                                  dry_run=False, as_spec=None, line=1))()
        with mock.patch.object(CLI, "ident", return_value={"login": "tester", "line": 1,
                                                          "token": "fake"}), \
             mock.patch.object(CLI, "guard", return_value={"push": True}), \
             mock.patch.object(G, "req", return_value=(200, pr)), \
             mock.patch("sys.stdout", new_callable=io.StringIO):
            with self.assertRaises(G.GhError) as cm:
                CLI.cmd_pr_merge(args)
        self.assertIn("不是 open", str(cm.exception))

    def test_11b_recalculating_mergeable_is_stopped(self):
        """base 变化后 GitHub 会短暂返回 mergeable=None，不能放它去撞 405。"""
        pr = {"title": "demo", "state": "open", "mergeable": None,
              "mergeable_state": "unknown", "head": {"sha": "a" * 40},
              "base": {"sha": "b" * 40}}
        args = type("A", (), dict(repo="o/r", merge=2, method="merge", message="",
                                  dry_run=True, as_spec=None, line=1))()
        with mock.patch.object(CLI, "ident", return_value={"login": "tester", "line": 1,
                                                          "token": "fake"}), \
             mock.patch.object(CLI, "guard", return_value={"push": True}), \
             mock.patch.object(G, "req", return_value=(200, pr)), \
             mock.patch("sys.stdout", new_callable=io.StringIO):
            with self.assertRaises(G.GhError) as cm:
                CLI.cmd_pr_merge(args)
        self.assertIn("重算", str(cm.exception))

    def test_11_help_lists_merge_flags(self):
        out = io.StringIO()
        with mock.patch("sys.stdout", out):
            try:
                CLI.build_parser().parse_args(["pr", "--help"])
            except SystemExit:
                pass
        text = out.getvalue()
        for flag in ("--merge", "--method", "--dry-run"):
            self.assertIn(flag, text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
