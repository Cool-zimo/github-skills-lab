---
name: github-skills
description: 多账号 GitHub 操作工具箱与行事准则。需要建仓（可指定组织 / 顺带开 Pages）、拉仓库（含 zipball 一次拉全）、整目录一次推送（默认合并语义，不删线上文件）、推送文件、快进分支、开启/查询 Pages、切换账号、查 PR / Pages / 协作者、校验线上与本地一致性，或写/审/改代码时遵循 Karpathy 四条准则时使用。含 CLI `github`、API 封装 ghlib.py、离线回归测试与 karpathy 原文镜像。
version: 1.3.2
license: MIT
---

# github-skills

自包含的多账号 GitHub 操作包。**零第三方依赖**，只用 Python 标准库 + GitHub REST API。

## 环境约定

- `.tokens` 在包根或向上 4 层内任意一级（更远用 `GH_TOKENS_FILE`），**每行一个 PAT，行号即账号编号**。不固定任何账号。
- 当前账号写在 `.active`（一行 login 或行号，不存 token）；没有 `.active` 时默认第 1 行。
- 账号切换优先级：`--as` > `github as <账号> ...` > `github <账号> ...` > `.active` > 第 1 行。
- 写操作前解析身份 + 查目标仓库 `permissions.push`；**指定了账号就必须精确匹配，绝不降级到别的行**。
- `GH_EXPECT_LOGIN` 可选强校验，默认不设。
- 本机 `git clone` 常返回 403 → 走 API 镜像（tree + contents）；大仓用 `pull --zip` 走 zipball，一次下载 + 一次 tree。
- **没找到 `.tokens` 时自动进入匿名只读模式**：tree / status / verify / pr / collab / pages 可查公开仓；写命令会明确要求 `.tokens`。
- `.ghproj` 存一行 JSON：`repo` / `branch` / `commit`（兼容 v1.2.0 纯文本）。分支优先读它，不再一律默认 `main`。
- 一致性用 **git blob sha**（`sha1("blob "+len+"\0"+bytes)`），与 API tree 的 sha 直接比。
- 工作仓库落 `projects/`，包内不预置仓库内容。
- **`sync` 默认合并语义**：`POST /git/trees` 带 `base_tree`，线上多出的文件保留；要删必须显式 `--mirror`。

## 命令

统一入口：`python3 github <命令>`（建议 `alias github='python3 /path/to/github-skills/github'`）

| 命令 | 作用 | 写? |
|---|---|---|
| `github users [--repo <o/r>]` | 账号管理：列所有账号 / scope / 对某仓库权限，**不显示 token 值** | 读 |
| `github use <账号>` / `--clear` | 设/清默认账号（写 `.active`） | 本地 |
| `github whoami` | 当前生效账号、行号、scope | 读 |
| `github doctor` | 环境自检 | 读 |
| `github tree <o/r> [--ref] [--limit]` | 文件树 | 读 |
| `github status <o/r>` | 仓库 + 我的权限 + Pages + 最新构建 | 读 |
| `github pr <o/r> [--state]` | PR / 标签 / mergeable | 读 |
| `github collab <o/r>` | 协作者与权限 | 读 |
| `github new repo <名> [--private] [--dry-run]` | 建仓并拉到 `projects/` | **写** |
| `github clone <o/r> [dir]` | git clone，403 自动回退 API | 本地 |
| `github pull <o/r> [dir] [--force]` | 纯 API 镜像 + 逐字节校验 | 本地 |
| `github verify <dir> [--repo <o/r>]` | 本地 vs 线上逐字节校验 | 读 |
| `github sync <dir> -m <msg> [--repo <o/r>] [--dry-run]` | **整目录一次 commit + 自动逐字节校验** | **写** |
| `github push <file> [--repo <o/r>] --path <p> -m <msg> [--dry-run]` | 推单文件（自动带 sha） | **写** |
| `github ff <o/r> <head> [--sha] [--base] [--dry-run]` | 单提交纯快进（force=false） | **写** |
| `github pages [o/r] [--enable] [--wait]` | 查 / 开 Pages + 等构建 | 读 / **写** |
| `github guide [路径] [--list]` | 打印 guides/ 下任意文档 | 读 |

**四种切账号写法等价**（以 causepotato 为例）：

```bash
github use causepotato                    # 设为默认，之后所有命令都用它
github as causepotato status <o/r>        # 单次，显式前缀
github causepotato status <o/r>           # 单次，直呼账号名
github status <o/r> --as causepotato      # 单次，参数形式
```

行号也能当账号：`github as 3 push ...`。`github new <名>` 与 `github new repo <名>` 等价。写命令都支持 `--dry-run`。

**v1.3.0 新增**：`pages`（查/开/等构建）、`pull --zip`、`clone --zip`、`new --owner / --pages`、`sync --mirror`（要删除时才用）、`verify --strict`、`guide --list` 与任意 guides/ 路径。

**包管理器 `spm`**：随包分发，默认把版本装到包内 `skills/`。支持仓库/直链/本地/**PR** 四种源、多版本并存、`trust` / `allow` / `safe` 门禁、VFS 隔离、自定义脚本与别名、token 文件同步。用法见 `SPM.md` 与 `guides/使用spm.md`。

## 标准工作流（每步带验证点）

```
1. github doctor                → 验证：账号解析成功、token 找到、文件齐
2. github users --repo <o/r>    → 验证：知道哪个账号对该仓库有 push 权限
3. github whoami                → 验证：当前账号 == 打算用的账号
4. github clone <o/r>           → 验证：N/N 逐字节一致；目录自动带 .ghproj
5. 改本地文件（只改必须改的行）  → 验证：diff 每行可追溯到请求；先写复现测试并跑通
6. github sync . -m "..." --dry-run → 验证：改动/复用/将删除清单正确
7. github sync . -m "..."       → 验证：commit sha + 末尾自动 N/N 逐字节一致；线上多出的文件被保留
8. github pages --enable --wait → 验证：Pages built、构建 commit == 该 sha（仓库名读 .ghproj）
```

**整目录优先用 `sync`，别逐文件 `push`**。`sync` 默认是**合并语义**：只在一次 commit 里推本地改动，线上多出的文件原样保留。只有显式 `--mirror` 才是镜像语义（不带 `base_tree`，会删线上多余文件），且 dry-run 会用 `⚠️` 列出将删除清单。无变化时不产生空提交。仓库名可省（读 `.ghproj`）；短名按当前账号补全。

快进合并额外两步：

```
github ff <o/r> <branch> --dry-run  → 验证：ahead=1 behind=0 status=ahead
github ff <o/r> <branch> --sha <前缀> --base <前缀>
                                → 验证：main 新 sha、Pages built
```

**不是纯快进就停止**；不加 `--force`；不覆盖协作者提交。两边并行推同一文件时会撞 409，推前先拉最新。

## 行事准则（Karpathy 四条，全文见 `AGENTS.md` / `guides/karpathy/`）

1. **编码前思考** — 不假设、不藏困惑。有歧义列出来问，有更简单做法直说。
2. **简洁优先** — 只写解决问题的最少代码；不加没要的功能/抽象/兜底。
3. **精准修改** — 只碰必须碰的行，匹配原有风格；只清理自己造成的孤儿。
4. **目标驱动** — 把「修个 bug」翻译成「先写复现 → 让它通过 → 验不回归」，每步可验证。

判断生效：diff 里无关改动更少、澄清问题出现在实现之前、没有顺带的重构。

## 硬约束

- **token 值永不打印、永不提交**；交付包里只有 `.tokens.example`。
- 不用 `--force` 推分支；不删他人分支；**默认不删线上任何文件**（删除必须 `--mirror`）；不改仓库设置（除非明确授权）。
- 匿名只读身份不允许写操作；写前 `guard()` 会先拒绝，不会把没 token 的请求发出去。
- 第三方仓库的 PR **不代提**：上游 `AGENTS.md` 明写不接受 AI 生成 PR，人审过也不豁免（见 `guides/踩坑记录.md`）。
- 建仓/推送前先 `--dry-run`；验证阶段不制造真实写入。

## 目录

```
github-skills/
├── SKILL.md  AGENTS.md  README.md  .tokens.example  .gitignore
├── github                ← CLI 唯一入口
├── ghlib.py              ← 薄 REST 封装（唯一 API 实现源）
├── spm / spmlib/         ← skill 包管理器（默认装到 skills/，见 SPM.md）
├── CHANGELOG.md          ← v1.3.0 逐条改动与验证点
├── tests/test_v130.py    ← 24 项离线回归（复现 v1.2.0 的 6 个问题）
├── .active               ← 运行时生成，不进交付包
├── projects/             ← 工作仓库落地点
├── scripts/              ← 可单独拷走的现成脚本（都支持 --as）
│   ├── push.py  clone_via_api.py  verify_mirror.py  pages_status.py
└── guides/
    ├── 使用指南.md  踩坑记录.md
    └── karpathy/     ← forrestchang/andrej-karpathy-skills 原文 9 文件镜像
```
