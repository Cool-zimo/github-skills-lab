# github-skills v1.3.2

> 架构版：**spm 是包管理器，github-skills 和 sb3 是包**。三者分开。

## 为什么

之前 `github-skills.v.1.3.1.zip` 里同时塞了 CLI 本体和 `spm` 包管理器，
一个 zip 既是"包"又是"管理器"，装下来概念是混的。现在：

```
spm                      包管理器（独立源码树，仓库 spm/ 目录）
 ├── github-skills       包（packages/github-skills.v.1.3.2.zip）
 └── sb3                 包（packages/sb3.v.1.0.0.zip）
```

## 改了什么

- 从包内移除：`spm`、`spmlib/`、`SPM.md`、`guides/使用spm.md`、
  `examples/spm-config.json`、`examples/hello-skill/`、`tests/test_spm.py`
- 测试跟着拆：`test_v131.py` 里 4 项 `spm` 取单文件的回归移到 `spm/tests/test_sources.py`
- 包内回归 **32 项**（24 项 v1.3.0 + 8 项 v1.3.1 的大文件/`pr --merge`）
- spm 独立树回归 **40 项**（25 原 + 4 移入 + 11 新增的默认源/多包/换源）
- 合计仍是 61+ 项，一项没丢

## 行为变更

无。CLI 命令、参数、`sync` 合并语义、blob sha 逐字节校验、多账号管理全部不变。
只是**不再随包附带 spm**；要用包管理器请单独取 `spm/` 源码。

## 安装

```bash
python3 spm install github-skills          # 默认源 = 官方包仓库
python3 spm install github-skills@1.3.2
python3 spm use github-skills@1.3.2
python3 spm exec github-skills -- python3 github --help
```

换源：`spm source add mirror github:me/mirror@main:packages --default`
或 `spm source use <name>` / `spm install ... --source <name>` / `--from <spec>`。

## 验证点

```
包内      32/32 OK（-W error::ResourceWarning）
spm 独立  40/40 OK
干净解压  python3 github --help → v1.3.2
包内无 spm/spmlib/SPM.md
```
